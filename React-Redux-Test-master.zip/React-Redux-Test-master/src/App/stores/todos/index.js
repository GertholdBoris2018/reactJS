import createResource from 'App/stores/resources'

export default createResource('todos')
