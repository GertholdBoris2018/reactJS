import getActionTypesConstants from '../../utils/getActionTypesConstants'

import * as actions from './'

export default getActionTypesConstants(actions)
